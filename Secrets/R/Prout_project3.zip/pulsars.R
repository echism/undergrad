#Elizabeth Prout
#This is an attempt to identify pulsars through machine learning for application 
#in astrophysics
#
#Importing csv into data frame
pulsars<-read.csv('~/Documents/HTRU2/HTRU_2.csv')
#Looking at data
summary(pulsars)
str(pulsars)
#cleaning column names
names(pulsars)<-c("IPP.Mean","IPP.SD","Excess.Kurtosis.IPP","Skewness.IPP","Mean.DMSNR","SD.DMSNR","Excess.Kurtosis.DMSNR","Skewness.DMSNR","Class")
#Checking for incomplete cases
sum(complete.cases(pulsars))
#removing class from one copy of data
pulsars.unclassified <- pulsars
pulsars.unclassified$Class <- NULL
#scaling data
pulsars.unclassified<-scale(pulsars[, -9])
pulsars.unclassified<-as.data.frame(pulsars.unclassified)
#examining for scale
summary(pulsars.unclassified)
#running kmeans on pulsars with class taken out
PU.kmeans<-kmeans(pulsars.unclassified,2)
#looking at the kmeans results
PU.kmeans
#comparing kmeans results to 
table(pulsars$Class,PU.kmeans$cluster)
#visual comparison of the data
#used class plus one in these analyses to make the colors comparable
plot(pulsars[c("IPP.Mean","IPP.SD")], col= PU.kmeans$cluster)
plot(pulsars[c("IPP.Mean","IPP.SD")], col= pulsars$Class+1)
plot(pulsars[c("SD.DMSNR","Mean.DMSNR")], col= PU.kmeans$cluster)
plot(pulsars[c("SD.DMSNR","Mean.DMSNR")], col= pulsars$Class+1)
plot(pulsars[c("Excess.Kurtosis.IPP","Skewness.IPP")], col= PU.kmeans$cluster)
plot(pulsars[c("Excess.Kurtosis.IPP","Skewness.IPP")], col= pulsars$Class+1)
plot(pulsars[c("Excess.Kurtosis.DMSNR","Skewness.DMSNR")], col= PU.kmeans$cluster)
plot(pulsars[c("Excess.Kurtosis.DMSNR","Skewness.DMSNR")], col= pulsars$Class+1)
#after scaling the data, the machine learning algorithm was pretty successful!
#you can see it in the graphs and the table but to review...
#number of observations identified as non-pulsars
sum(PU.kmeans$cluster[PU.kmeans$cluster==2])/2
#actual number of observations that were non-pulsars
sum(pulsars$Class[pulsars$Class=="1"])
#number of observations identified as pulsars
sum(PU.kmeans$cluster[PU.kmeans$cluster==1])
#actual number of observations that were pulsars
nrow(pulsars)-sum(pulsars$Class[pulsars$Class=="1"])

